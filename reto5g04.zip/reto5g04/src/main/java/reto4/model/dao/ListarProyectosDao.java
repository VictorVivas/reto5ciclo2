package reto4.model.dao;


import java.sql.Statement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import reto4.model.vo.ListarProyectosVo;
import reto4.util.JDBCUtilities;

public class ListarProyectosDao {
    public List<ListarProyectosVo> listar() throws SQLException{
        List<ListarProyectosVo> respuesta = new ArrayList<ListarProyectosVo>();
        Connection conn = JDBCUtilities.getConnection();
        Statement stm = null;
        ResultSet rs = null;
        String sql = "select ID_Proyecto as proyecto, Constructora, Numero_Habitaciones as habitaciones, Ciudad from Proyecto p where Clasificacion = 'Casa Campestre' and Ciudad in('Santa Marta', 'Cartagena', 'Barranquilla')";
        try{
            stm = conn.createStatement();
            //stm.setString(1, banco);
            rs = stm.executeQuery(sql);
            while(rs.next()) {
                ListarProyectosVo vo = new ListarProyectosVo();
                vo.setProyecto(rs.getInt("proyecto"));
                vo.setConstructora(rs.getString("constructora"));
                vo.setHabitaciones(rs.getInt("habitaciones"));
                vo.setCiudad(rs.getString("ciudad"));
                respuesta.add(vo);
            }
        }
        finally{
            if(rs != null){
                rs.close();
            }
            if(stm != null){
                stm.close();
            }
            if(conn != null){
                conn.close();
            }
        }
        return respuesta;

    }
    
}
