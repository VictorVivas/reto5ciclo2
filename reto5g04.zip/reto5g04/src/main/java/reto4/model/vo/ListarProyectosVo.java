package reto4.model.vo;

public class ListarProyectosVo {
    //proyecto, constructora, habitaciones, ciudad
    
    private Integer proyecto;
    private String constructora;
    private Integer habitaciones;
    private String ciudad;

    public Integer getProyecto() {
        return proyecto;
    }
    public void setProyecto(Integer proyecto) {
        this.proyecto = proyecto;
    }
    public String getConstructora() {
        return constructora;
    }
    public void setConstructora(String constructora) {
        this.constructora = constructora;
    }
    public Integer getHabitaciones() {
        return habitaciones;
    }
    public void setHabitaciones(Integer habitaciones) {
        this.habitaciones = habitaciones;
    }
    public String getCiudad() {
        return ciudad;
    }
    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }
    
}
