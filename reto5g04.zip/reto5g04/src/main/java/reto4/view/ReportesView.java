package reto4.view;

import java.util.List;

import reto4.controller.ReportesController;
import reto4.model.vo.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.*;

public class ReportesView extends JFrame implements ActionListener{
    private ReportesController controller;
    private JMenuBar menuBar;
    private JMenu menu;
    private JMenu menu2;
    private JMenuItem primerInf, segundoInf, tercerInf;
    private JMenuItem limpiar;
    private JTable tabla;
    private DefaultTableModel modelo;
    private JFrame frame;
   
    private JLabel lblTitulo, lblConsulta;

    public ReportesView() {
        controller = new ReportesController();
        menu();
        menu2();
        etiqueta1();
        etiqueta2();
        tabla();


    }

    public void menu(){
        menuBar = new JMenuBar();
        setJMenuBar(menuBar);
        menu = new JMenu("Informes");
        menuBar.add(menu);
        primerInf = new JMenuItem("Informe N° 1");
        segundoInf = new JMenuItem("Informe N° 2");
        tercerInf = new JMenuItem("Informe N° 3");
        menu.add(primerInf);
        menu.add(segundoInf);
        menu.add(tercerInf);
        primerInf.addActionListener(this);
        segundoInf.addActionListener(this);
        tercerInf.addActionListener(this);
    }

    public void menu2(){
        menu2 = new JMenu("Herramientas");
        menuBar.add(menu2);
        limpiar = new JMenuItem("Limpiar pantalla");
        menu2.add(limpiar);
        limpiar.addActionListener(this);
    }

    public void etiqueta1() {
        lblTitulo = new JLabel("Informe Reto 5");
        lblTitulo.setPreferredSize(new Dimension(500, 30));
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 20));
        add(lblTitulo);
    }

    public void etiqueta2() {
        lblConsulta = new JLabel();
        lblConsulta.setPreferredSize(new Dimension(500, 30));
        lblConsulta.setFont(new Font("Arial", Font.BOLD, 14));
        add(lblConsulta);
    }

    public void tabla(){
        tabla = new JTable(modelo);
        tabla.setPreferredScrollableViewportSize(new Dimension(500,200));

        add(tabla);
        JScrollPane pane = new JScrollPane(tabla);
        add(pane);

    }


    public void lideres() {
        try {
            List<ListarLideresVo> lideres = controller.listarLideres();
            //crear el modelo
            modelo = new DefaultTableModel();
            modelo.addColumn("ID_Lider");
            modelo.addColumn("Nombre");
            modelo.addColumn("Apellido");
            modelo.addColumn("Ciudad");

            for (ListarLideresVo i : lideres) {
                Object[] fila = new Object[4];
                fila[0] = i.getId();
                fila[1] = i.getNombre();
                fila[2] = i.getApellido();
                fila[3] = i.getCiudad();
                modelo.addRow(fila);
            }
            tabla.setModel(modelo);
            modelo.fireTableDataChanged();

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }

    }

    public void proyectos() {
        try {
            List<ListarProyectosVo> proyectos = controller.listarProyectos();
            //crear el modelo
            modelo = new DefaultTableModel();
            modelo.addColumn("ID_Proyecto");
            modelo.addColumn("Constructora");
            modelo.addColumn("Habitaciones");
            modelo.addColumn("Ciudad");

            for (ListarProyectosVo i : proyectos) {
                Object[] fila = new Object[4];
                fila[0] = i.getProyecto();
                fila[1] = i.getConstructora();
                fila[2] = i.getHabitaciones();
                fila[3] = i.getCiudad();
                modelo.addRow(fila);
            }
            tabla.setModel(modelo);
            modelo.fireTableDataChanged();            

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }

    }

    public void compras() {
        try {
            List<ListarComprasVo> compras = controller.listarCompras();
            //crear el modelo
            modelo = new DefaultTableModel();
            modelo.addColumn("ID_Compra");
            modelo.addColumn("Constructora");
            modelo.addColumn("Banco");    

            for (ListarComprasVo i : compras) {
                Object[] fila = new Object[3];
                fila[0] = i.getId();
                fila[1] = i.getConstructora();
                fila[2] = i.getBanco();
                modelo.addRow(fila);
            }
            tabla.setModel(modelo);
            modelo.fireTableDataChanged(); 

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }

    }

    public void limpiar(){
        try {

            
            //crear el modelo
            modelo = new DefaultTableModel();
            tabla.setModel(modelo);
            //modelo.fireTableDataChanged(); 

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }        
    }



    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == primerInf){
            lideres();
            lblConsulta.setText("Consulta de lideres");
        }

        if(e.getSource() == segundoInf){
            proyectos();
            lblConsulta.setText("Consulta de Proyectos");
        }

        if(e.getSource() == tercerInf){
            compras();
            lblConsulta.setText("Consulta de Compras");
        }

        if(e.getSource() == limpiar){
            JOptionPane.showMessageDialog(frame, "Se borraran los datos de la pantalla!.", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
            limpiar();
            lblConsulta.setText("");
        }
        
    }



}
