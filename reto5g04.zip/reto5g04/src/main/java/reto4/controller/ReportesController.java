package reto4.controller;

import java.sql.SQLException;
import java.util.List;

import reto4.model.dao.*;
import reto4.model.vo.*;

public class ReportesController {
    private ListarProyectosDao listarProyectosDao;
    private ListarLideresDao listarLideresDao;
    private ListarComprasDao listarComprasDao;

    public ReportesController(){
        listarProyectosDao = new ListarProyectosDao();
        listarLideresDao = new ListarLideresDao();
        listarComprasDao = new ListarComprasDao();
    }

    public List<ListarLideresVo> listarLideres() throws SQLException{
        return listarLideresDao.listar();
    }

    public List<ListarProyectosVo> listarProyectos() throws SQLException{
        return listarProyectosDao.listar();
    }

    public List<ListarComprasVo> listarCompras() throws SQLException{
        return listarComprasDao.listar();
    }

}
